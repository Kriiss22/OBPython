import operations


def main():

    res1 = operations.addition(5,6)
    res2 = operations.division(4,2)
    res3 = operations.subtraction(8,5)
    res4 = operations.multiplication(5,3)

    print(res1,res2,res3,res4)


if __name__ == '__main__':
    main()