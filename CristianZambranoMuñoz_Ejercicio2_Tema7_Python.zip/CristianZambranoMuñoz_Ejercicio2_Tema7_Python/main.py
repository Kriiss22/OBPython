import time

def main():

    hour = time.strftime('%H:%M:%S', time.localtime())
    actualHour = int(time.strftime('%H', time.localtime()))

    print(actualHour)

    if actualHour < 19 :

        res = 19 - actualHour
        print("Aun no es hora de irse, quedan", res, 'horas')
    else :
        print("Ya es hora de irse son las", hour)

if __name__=='__main__':
    main()